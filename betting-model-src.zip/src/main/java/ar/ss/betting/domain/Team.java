package ar.ss.betting.domain;

import java.util.Objects;

/**
 * Represents a team participating in a Match.
 */
public class Team {

    private final String name;

    public Team(String name) {
        this.name = Objects.requireNonNull(name, "Team name cannot be null");

        if (name.isBlank()) {
            throw new IllegalArgumentException("Team name cannot be blank");
        }
    }

    public String getName() {
        return name;
    }
}
